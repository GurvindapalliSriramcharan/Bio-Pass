# Pydantic and SQLAlchemy models here
