# OTP generation and verification logic here
