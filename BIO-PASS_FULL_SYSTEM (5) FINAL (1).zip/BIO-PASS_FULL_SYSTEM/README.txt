BIO-PASS Setup Instructions:
1. Run backend using FastAPI
2. Open frontend/index.html in browser.